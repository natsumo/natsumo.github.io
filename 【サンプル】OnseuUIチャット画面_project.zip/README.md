# OnsenUIChatSample

* 公開URL： https://monaca.mobi/ja/directimport?pid=5e6b286de788851c0a4d2b59
